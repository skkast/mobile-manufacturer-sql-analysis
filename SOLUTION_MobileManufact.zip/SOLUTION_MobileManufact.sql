--SQL Advance Case Study


--Q1--BEGIN 
	
	SELECT distinct(State) from DIM_LOCATION as d
	inner join FACT_TRANSACTIONS as t
	on d.IDLocation=t.IDLocation
	where year(date) between 2005 and (Select year(Max(date)) from FACT_TRANSACTIONS)

--Q1--END

--Q2--BEGIN
	--SELECT * FROM DIM_Model

	SELECT top 1 State,sum(Quantity) as cellpone_counnt FROM DIM_LOCATION as d
	inner join FACT_TRANSACTIONS as f
	on d.IDLocation=f.IDLocation
	Where 
	IDModel in(
	SELECT IDModel FROM DIM_MODEL as d
	inner join DIM_MANUFACTURER as dm
	on d.IDManufacturer=dm.IDManufacturer
	where Manufacturer_Name='Samsung')
	AND Country='US'
	group by State

--Q2--END

--Q3--BEGIN      
	
	SELECT ZipCode,State,Model_Name,count(Model_Name) as transaction_count from DIM_LOCATION as d
	inner join FACT_TRANSACTIONS as f
	on d.IDLocation=f.IDLocation
	Inner join DIM_MODEL as dm
	on f.IDModel=dm.IDModel
	group by ZipCode,State,Model_Name

--Q3--END

--Q4--BEGIN

SELECT Model_Name,Unit_price FROM DIM_MODEL
WHERE Unit_price In
(SELECT MIN(Unit_price) FROM DIM_MODEL)

--Q4--END

--Q5--BEGIN

 select Model_Name,AVG(totalPrice) as Avg_price from DIM_MODEL as d
 inner join FACT_TRANSACTIONS as f
 on d.IDModel=f.IDModel
 where IDManufacturer in(
SELECT top 5 IDManufacturer--AVG(TotalPrice)as avg_price,sum(Quantity)as Quantity 
FROM DIM_MODEL as dm
inner join FACT_TRANSACTIONS as f
on dm.IDModel=f.IDModel
group by IDManufacturer
order by sum(Quantity) desc,AVG(TotalPrice) desc
)
group by Model_Name
--Q5--END

--Q6--BEGIN

SELECT Customer_Name FROM (
SELECT Customer_Name,AVG(TotalPrice)as avg_spent FROM DIM_CUSTOMER as dc
inner join FACT_TRANSACTIONS as f
on dc.IDCustomer=f.IDCustomer
where year(date)=2009
group by Customer_Name
having AVG(TotalPrice)>500
) AS X


--Q6--END
	
--Q7--BEGIN  
--select * from FACT_TRANSACTIONS
SELECT * FROM(
SELECT top 5  Model_Name --sum(Quantity)As qty_count 
FROM DIM_MODEL as d
inner join FACT_TRANSACTIONS as f
on d.IDModel=f.IDModel
where year(Date)=2008
group by Model_Name
order by sum(Quantity)desc) AS X
INTERSECT
SELECT * FROM (
SELECT top 5  Model_Name --sum(Quantity)As qty_count 
FROM DIM_MODEL as d
inner join FACT_TRANSACTIONS as f
on d.IDModel=f.IDModel
where year(Date)=2009
group by Model_Name
order by sum(Quantity)desc
) AS Y
INTERSECT
SELECT * FROM(
SELECT top 5  Model_Name--sum(Quantity)As qty_count 
FROM DIM_MODEL as d
inner join FACT_TRANSACTIONS as f
on d.IDModel=f.IDModel
where year(Date)=2010
group by Model_Name
order by sum(Quantity)desc
) AS Z
--Q7--END	
--Q8--BEGIN
SELECT * FROM(
SELECT Manufacturer_Name, SUM(TotalPrice) as Tot_sales,Rank()over(order by SUM(TotalPrice) desc) as rank
--Dense_Rank()over(partition by Manufacturer_Name order by sum(TotalPrice)desc )
from DIM_MODEL as dm
inner join FACT_TRANSACTIONS as f
on dm.IDModel=f.IDModel
inner join DIM_MANUFACTURER as d
on d.IDManufacturer=dm.IDManufacturer
where year(Date)=2009
group by Manufacturer_Name)
AS X
where rank=2
UNION ALL
SELECT * FROM(
SELECT Manufacturer_Name, SUM(TotalPrice) as Tot_sales,Rank()over(order by SUM(TotalPrice) desc) as rank
--Dense_Rank()over(partition by Manufacturer_Name order by sum(TotalPrice)desc )
from DIM_MODEL as dm
inner join FACT_TRANSACTIONS as f
on dm.IDModel=f.IDModel
inner join DIM_MANUFACTURER as d
on d.IDManufacturer=dm.IDManufacturer
where year(Date)=2010
group by Manufacturer_Name
) AS Y
Where rank=2

--Q8--END
--Q9--BEGIN
	
	SELECT distinct(Manufacturer_Name) FROM DIM_MODEL as dm
	inner join FACT_TRANSACTIONS as f
	on dm.IDModel=f.IDModel
	inner join DIM_MANUFACTURER as d
	on d.IDManufacturer=dm.IDManufacturer
	where YEAR(Date)=2010
	EXCEPT
	SELECT distinct(Manufacturer_Name) FROM DIM_MODEL as dm
	inner join FACT_TRANSACTIONS as f
	on dm.IDModel=f.IDModel
	inner join DIM_MANUFACTURER as d
	on d.IDManufacturer=dm.IDManufacturer
	where YEAR(Date)=2009
--Q9--END

--Q10--BEGIN
	
With top10_cust
AS(

SELECT top 10 IDCustomer,AVG(TotalPrice) as avg_amt,AVG(Quantity) as avg_qty
FROM FACT_TRANSACTIONS
group by IDCustomer
order by avg_amt desc,avg_qty desc
),
--SELECT * FROM top10_cust
YearWise_Spend
AS(

SELECT YEAR(Date)as YEAR,IDCustomer,AVG(totalPrice) As Avg_spend,Avg(Quantity) as Avg_quantity
from FACT_TRANSACTIONS
where IDCustomer in (SELECT IDCustomer from top10_cust)
group by YEAR(Date),IDCustomer 
--order by YEAR asc
),
Change_Spend
AS(
SELECT *,LAG(Avg_spend)over(order by IDCUSTOMER asc)As prev_avg_spend FROM YearWise_Spend
)
SELECT * FROM Change_Spend


--Q10--END
	